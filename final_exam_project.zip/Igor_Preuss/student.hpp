#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>

using namespace std;

struct Student{
    string name;
    string surname;
    vector<int> grades;
    double final_grade;
    int minimum_grade;
};

void fill_Student_Vector(std::vector<Student> &students);
double final_grade_calculation(const Student &students);
void sort_students_by_grade (vector<Student> &student,bool by_grade);
