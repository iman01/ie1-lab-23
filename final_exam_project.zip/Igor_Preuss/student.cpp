#include "student.hpp"

bool sorting_by_final_grade(const Student &student1,const Student &student2){
    return student1.final_grade>student2.final_grade;
}

bool sorting_by_minimum_grade(const Student &student1,const Student &student2){
    return student1.minimum_grade>student2.minimum_grade;
}

void sort_students_by_grade (vector<Student> &student,bool by_grade){
    if(by_grade){
        sort(student.begin(),student.end(),sorting_by_final_grade);
    }
    else{
        sort(student.begin(),student.end(),sorting_by_minimum_grade);
    }
}

void fill_Student_Vector(std::vector<Student> &students){
    vector<int>::iterator minimum_grade;
    fstream file;
    file.open("grades.txt", std::ios::in);
    file.seekp(0,ios::beg);
    string line;
    while(getline(file, line)){
        Student a;
        size_t pos;
        pos=line.find(',');
        a.name=line.substr(0, pos);
        line = line.substr(pos+1);
        pos = line.find(',');

        a.surname = line.substr(0, pos);
        line = line.substr(pos+1);

        for(int i = 0; i < 7; i++){
            pos = line.find(',');
            int b = std::stoi(line.substr(0, pos));
            a.grades.emplace_back(b);
            line = line.substr(pos+1);
        }

        minimum_grade= std::min_element(a.grades.begin(), a.grades.end());
        a.minimum_grade=*minimum_grade;
        students.emplace_back(a);
    }
}

double final_grade_calculation(const Student &students){
    double percentage;double grade;
    double sum=accumulate(students.grades.begin(),students.grades.end(),0.0);
    percentage=(sum/70)*100.0;
    if(percentage>=91){
        grade=5.0;
    }
    else if(percentage>=81){
        grade=4.50;
    }
    else if(percentage>=71){
        grade=4.25;
    }
    else if(percentage>=61){
        grade=3.50;
    }
    else if(percentage>=51){
        grade=3.25;
    }
    else{
        grade=2.25;
    }
    return grade;
}
