#include "student.hpp"

int main()
{
    vector<Student> students;
    fill_Student_Vector(students);

    cout<<"---------------STUDENTS AND THEIR FINAL GRADES (UNSORTED)"<<endl;
    for(auto &student:students){
        student.final_grade=final_grade_calculation(student);
        cout<<student.name<<" "<<student.surname<<" "<<student.final_grade<<endl;
    }

    cout<<"---------------STUDENTS SORTED BY THEIR FINAL GRADE"<<endl;
    sort_students_by_grade(students,true);
    for(auto &student:students){
        cout<<student.name<<" "<<student.surname<<" "<<student.final_grade<<endl;
    }

    cout<<"---------------STUDENTS SORTED BY THEIR MINIMUM GRADE"<<endl;
    sort_students_by_grade(students,false);
    for(auto &student:students){
        cout<<student.name<<" "<<student.surname<<" "<<student.minimum_grade<<endl;
    }

    return 0;
}
